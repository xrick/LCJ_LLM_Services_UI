export const THINKING_BLOCK_CONTROLS_SELECTORS = [
  "pre:first-child .text-text-300.absolute",
  "pre:first-child .pointer-events-none.sticky",
].join(", ")
