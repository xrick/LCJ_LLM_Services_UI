export const GITHUB_API_URL =
  "https://api.github.com/repos/richards199999/Thinking-Claude/contents/model_instructions"

export const MESSAGE_SOURCE = "thinking-claude" as const
export const MESSAGE_TYPE = {
  CONTENT_CHANGED: "CONTENT_CHANGED",
} as const
